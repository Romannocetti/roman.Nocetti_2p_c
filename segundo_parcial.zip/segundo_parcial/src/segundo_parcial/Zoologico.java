package segundo_parcial;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public class Zoologico<T extends CSVSerializable & Comparable<T>> {  

    private List<T> elementos;

    public Zoologico() {
        elementos = new ArrayList<>();
    }


    public void agregar(T elemento) {
        elementos.add(elemento);
    }


    public void paraCadaElemento(Consumer<T> accion) {
        for (T elemento : elementos) {
            accion.accept(elemento);
        }
    }


    public List<T> filtrar(Filtro<T> filtro) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (filtro.cumple(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }


    public void ordenar() {
        Collections.sort(elementos);  
    }


    public void ordenar(Comparator<T> comparator) {
        Collections.sort(elementos, comparator);
    }

    public void ordenarPorNombre() {
        Comparator<T> comparator = Comparator.comparing(e -> ((Animal) e).getNombre());
        Collections.sort(elementos, comparator);
    }


    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(path))) {
            output.writeObject(elementos);
        }
    }


    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            elementos = (List<T>) input.readObject();
        }
    }


    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,especie,nombre,alimentacion\n");
            for (T elemento : elementos) {
                bw.write(elemento.toCSV());
               bw.newLine();
            }
        }
    }


    public void cargarDesdeCSV(String path) throws IOException {
        
        List<T> nuevaLista = new ArrayList<>();
        
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                Animal animal = Animal.fromCSV(linea);
                if (animal != null) {
                    nuevaLista.add((T) animal); 
                }
            }
        }
        elementos = nuevaLista;
    }

    public interface Filtro<T> {
        boolean cumple(T elemento);
    }

}
