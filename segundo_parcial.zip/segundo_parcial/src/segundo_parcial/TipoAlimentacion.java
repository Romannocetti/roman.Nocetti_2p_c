package segundo_parcial;

public enum TipoAlimentacion {

    CARNIVORO,HERBIVORO, OMNIVORO, INSECTIVORO
}
