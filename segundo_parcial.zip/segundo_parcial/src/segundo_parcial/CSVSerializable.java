package segundo_parcial;

public interface CSVSerializable {

    String toCSV();


}
